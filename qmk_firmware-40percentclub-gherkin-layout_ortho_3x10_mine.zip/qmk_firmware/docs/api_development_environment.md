# Development Environment Setup

To setup a development stack head over to the [qmk_web_stack](https://github.com/qmk/qmk_web_stack).
